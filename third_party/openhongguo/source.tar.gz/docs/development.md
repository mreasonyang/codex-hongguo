# 开发

本文说明 openhongguo 怎样保证兼容性。有两种检查：每日的接口契约检查，以及每次推送时运行的持续集成。

## 接口契约检查

契约检查用于发现服务端的改版。

`testdata/protocol/` 中的响应样本是解析器使用的契约。真实接口必须继续提供样本中的每个字段路径和 JSON 类型。

### 检查的内容

检查按 CLI 的调用顺序请求真实接口，并把每个响应与样本比较。检查以下接口：

- 发现、搜索、短剧的详情和播放模型。
- 联想词、推荐、多季、批量详情、热搜和分类。
- 书城榜单、短剧筛选面板和筛选结果、短剧榜。
- 演员榜、演员主页、上新和搜索提示词。

比较以后，检查确认结果可以使用：

- 搜索找到短剧。
- 分集的编号连续。
- 播放模型包含流。
- 恢复出的内容密钥能用 ffmpeg 解密一帧。
- 各个列表不为空。
- 短剧榜的前几名是视频。

检查不包括活动榜。如果活动没有开放，活动榜本来就没有条目。

### 运行检查

运行以下命令：

```sh
go test -tags live -run TestLiveContract -v ./internal/contract
```

用以下环境变量调整检查：

| 环境变量 | 作用 |
|---|---|
| `OHG_CONFIG_DIR` | 使用已有的匿名设备。如果不设置，每次注册一台新的匿名设备，同时检查注册响应 |
| `OHG_CONTRACT_QUERY` | 搜索词。默认值是 `全球死考` |
| `OHG_CONTRACT_MOVIE` | 另外检查一部分段（DASH）电影。值是短剧 ID。检查使用样本 `dynamic-playback.json` |
| `OHG_CONTRACT_OUT` | 把报告和真实响应的结构写入这个目录，用于与样本比较。结构只有路径和类型，不包含值 |

> **注意**：不带 `-tags live` 时，`go test ./...` 不访问网络。

`.github/workflows/contract.yml` 每天运行一次检查，并把结构文件上传为 artifact。

### 处理漂移

如果服务端改版，检查列出漂移的字段，例如 `data.video_data.video_list[].title: missing (fixture has string)`。

以下情况不是漂移：

- 真实响应中多出的字段。解析器忽略这些字段。
- 样本中是字符串、数字或布尔值，真实响应中是 null。解析器把 null 读为零值。

如果修改了解析器，同时更新对应的样本。

> **注意**：样本只保留解析器读取的字段。这样，无关字段的变化不会使检查失败。

## 持续集成

每次推送和每个 pull request 都运行 `.github/workflows/ci.yml`。持续集成不访问网络。各平台的 SDK 用 `testdata/protocol` 的样本回放测试。

| 任务 | 内容 |
|---|---|
| Go | 格式检查、`go vet` 和所有测试。同时检查生成的类型和文档是否过时 |
| Node.js | 在 Node.js 20 和 22 上构建 wasm 并运行测试 |
| Android | 编译 aar，运行 Kotlin 单元测试，然后在模拟器上运行设备测试 |
| iOS | 编译 xcframework，在 macOS 上运行 Swift 测试，然后为 iOS 真机和模拟器编译 |
| React Native | 编译 TypeScript，用假的原生模块测试客户端 |
| Flutter | 用模拟的平台通道测试客户端 |

> **注意**：如果一次推送只修改文档，持续集成不运行。
